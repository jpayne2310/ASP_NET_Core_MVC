﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SE406_Payne.Models
{
    public class FunctionalClassViewModel
    {
        public List<FunctionalClass> FunctionalClassList { get; set; }
        public FunctionalClass NewFunctionalClass { get; set; }
    }
}

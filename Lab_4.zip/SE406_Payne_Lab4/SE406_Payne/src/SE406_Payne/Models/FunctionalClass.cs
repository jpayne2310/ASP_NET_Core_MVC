﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SE406_Payne.Models
{
    public class FunctionalClass
    {
        public Guid FunctionalClassId { get; set; }
        public string FunctionalClassType { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SE406_Payne.Models
{
    public class ConstructionDesign
    {
        public Guid ConstructionDesignId { get; set; }
        public string ConstructionDesignType { get; set; }
    }
}

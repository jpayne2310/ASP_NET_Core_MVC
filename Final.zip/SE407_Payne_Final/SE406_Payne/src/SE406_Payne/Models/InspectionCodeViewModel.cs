﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SE406_Payne.Models
{
    public class InspectionCodeViewModel
    {
        public List<InspectionCode> InspectionCodeList { get; set; }
        public InspectionCode NewInspectionCode { get; set; }
    }
}

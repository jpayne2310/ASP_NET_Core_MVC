﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SE406_Payne.Models
{
    public class InspectorViewModel
    {
        public List<Inspector> InspectorList { get; set; }
        public Inspector NewInspector { get; set; }
    }
}
